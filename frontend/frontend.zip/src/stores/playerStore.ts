import type { Metadata } from "@/types/song";
import { create } from "zustand";

interface PlayerStoreProps {
	id?: number;
	url?: string;
	title: string;
	duration?: number;
	coverArt?: string;
	artist?: string;
	album?: string;
	year?: number;
	isPlaying: boolean;
	currentTime: number;
	volume: number;
	isMuted: boolean;
	shuffle: boolean;
	repeat: "off" | "all" | "one";

	setPlayer: (metadata: Metadata) => void;
	clearPlayer: () => void;

	setIsPlaying: (playing: boolean) => void;
	setCurrentTime: (time: number) => void;
	setDuration: (duration: number) => void;
	setVolume: (volume: number) => void;
	setIsMuted: (muted: boolean) => void;
	setShuffle: (shuffle: boolean) => void;
	setRepeat: (repeat: "off" | "all" | "one") => void;
}

const initstate = {
	id: undefined,
	url: undefined,
	title: "Unknown",
	duration: undefined,
	coverArt: "",
	artist: "Unknown",
	album: "Unknown",
	year: undefined,
	isPlaying: false,
	currentTime: 0,
	volume: 1,
	isMuted: false,
	shuffle: false,
	repeat: "off" as const,
};

const usePlayerStore = create<PlayerStoreProps>((set) => ({
	...initstate,
	setPlayer: (metadata) =>
		set({
			...metadata,
			currentTime: 0,
			isPlaying: false,
		}),

	clearPlayer: () => set({ ...initstate }),

	setIsPlaying: (isPlaying) => set({ isPlaying }),
	setCurrentTime: (currentTime) => set({ currentTime }),
	setDuration: (duration) => set({ duration }),
	setVolume: (volume) => set({ volume }),
	setIsMuted: (isMuted) => set({ isMuted }),
	setShuffle: (shuffle) => set({ shuffle }),
	setRepeat: (repeat) => set({ repeat }),
}));

export default usePlayerStore;
